#!/bin/bash

#echo "Setting up vars for downstream Hadoop..."
#. ./setup-vars-downstream.sh

echo "Setting up vars for upstream Hadoop..."
. ./setup-vars-upstream.sh